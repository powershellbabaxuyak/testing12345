# github-actions-benchmark
Experimental GitHub Actions runner inspection and CPU stress test
